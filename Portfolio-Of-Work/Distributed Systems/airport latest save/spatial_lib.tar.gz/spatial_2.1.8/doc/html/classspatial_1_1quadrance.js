var classspatial_1_1quadrance =
[
    [ "check_concept_distance_type_is_arithmetic", "classspatial_1_1quadrance.html#aced34c4699fc07f0557529644f9cc47c", null ],
    [ "difference_type", "classspatial_1_1quadrance.html#a8bb007b4a290adf7050859a2ad2fedaa", null ],
    [ "distance_type", "classspatial_1_1quadrance.html#a015985369afe11a2fdb677e7a445b6ee", null ],
    [ "key_type", "classspatial_1_1quadrance.html#ad8522af7586197f6299729259f895894", null ],
    [ "quadrance", "classspatial_1_1quadrance.html#abd63351375a2758c5f1baae9475c119e", null ],
    [ "quadrance", "classspatial_1_1quadrance.html#a9da48782bf7dd60c0908b660cf76830d", null ],
    [ "difference", "classspatial_1_1quadrance.html#a0cdd48ea749c7e5ec69180da5f70a99a", null ],
    [ "distance_to_key", "classspatial_1_1quadrance.html#ab28eca94ffdc261038b82a05cd6e52be", null ],
    [ "distance_to_plane", "classspatial_1_1quadrance.html#a1516039bb619921ef1452b10cc5c1925", null ]
];