var annotated_dup =
[
    [ "spatial", "namespacespatial.html", "namespacespatial" ]
];