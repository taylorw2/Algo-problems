var index =
[
    [ "Features Overview", "index.html#feature", null ],
    [ "Getting the Source", "index.html#source", null ],
    [ "Status of the Library", "index.html#status", null ],
    [ "History of the Library", "index.html#history", null ],
    [ "Licensing", "index.html#license", null ],
    [ "Getting Support", "index.html#support", null ],
    [ "Change Log", "changelog.html", [
      [ "Version 2.1.8", "changelog.html#ver218", null ],
      [ "Version 2.1.7", "changelog.html#ver217", null ],
      [ "Version 2.1.6", "changelog.html#ver216", null ],
      [ "Version 2.1.5", "changelog.html#ver215", null ],
      [ "Version 2.1.4", "changelog.html#ver214", null ],
      [ "Version 2.1.3", "changelog.html#ver213", null ],
      [ "Version 2.1.2", "changelog.html#ver212", null ],
      [ "Version 2.1.1", "changelog.html#ver211", null ],
      [ "Version 2.1.0", "changelog.html#ver210", null ],
      [ "Version 2.0.1", "changelog.html#ver201", null ],
      [ "Version 2.0.0", "changelog.html#ver2", null ],
      [ "Version 1.0.0 (unsupported)", "changelog.html#ver1", null ]
    ] ],
    [ "Installing the library", "install.html", [
      [ "Windows and Visual Studio", "install.html#windows", null ],
      [ "Linux with autotools/cmake", "install.html#linux", null ],
      [ "Other platforms", "install.html#other_platforms", null ]
    ] ],
    [ "Quick Starting Guide", "tutorial.html", [
      [ "Choosing a Container", "tutorial.html#tutorial_step0", [
        [ "Overview", "tutorial.html#tutorial_step0_sub1", null ],
        [ "Usage of containers", "tutorial.html#tutorial_step0_sub2", null ],
        [ "Determining dimension at runtime", "tutorial.html#tutorial_step0_sub3", null ]
      ] ],
      [ "Inserting Any Type of Objects", "tutorial.html#tutorial_step1", null ],
      [ "Basic operations on containers", "tutorial.html#tutorial_step2", null ],
      [ "Spatial operations on containers", "tutorial.html#tutorial_step3", [
        [ "Orthogonal range search", "tutorial.html#tutorial_range", null ],
        [ "Nearest neighbor search", "tutorial.html#tutorial_ann", null ],
        [ "Mapping of the container onto a single dimension", "tutorial.html#tutorial_mapping", null ]
      ] ]
    ] ],
    [ "Contributing", "contributing.html", [
      [ "I've noticed a bug...", "contributing.html#contributing_1", null ],
      [ "I would love if...", "contributing.html#contributing_2", null ],
      [ "How can I help?", "contributing.html#contributing_3", null ],
      [ "How can I become a contributor?", "contributing.html#contributing_4", null ],
      [ "What guidelines to follow when contributing?", "contributing.html#contributing_5", null ],
      [ "Hey this library is cool!", "contributing.html#contributing_6", null ]
    ] ],
    [ "Compilation Options", "compileopts.html", [
      [ "SPATIAL_BAD_CSTDDEF", "compileopts.html#compileopts_1", null ],
      [ "SPATIAL_SAFER_ARITHMETICS", "compileopts.html#compileopts_2", null ],
      [ "SPATIAL_ENABLE_ASSERT", "compileopts.html#compileopts_3", null ]
    ] ]
];