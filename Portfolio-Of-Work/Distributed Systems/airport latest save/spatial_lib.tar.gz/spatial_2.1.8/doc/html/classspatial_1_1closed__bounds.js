var classspatial_1_1closed__bounds =
[
    [ "closed_bounds", "classspatial_1_1closed__bounds.html#aa6c648767475e557fa42a87c686546dc", null ],
    [ "closed_bounds", "classspatial_1_1closed__bounds.html#a5eb57407d4db0a8a5c264a54b5eb26a6", null ],
    [ "operator()", "classspatial_1_1closed__bounds.html#ac11a02c92d2f12804adca4456263dca6", null ],
    [ "_lower", "classspatial_1_1closed__bounds.html#a04e01a3c956b484df02fb16f00529ddb", null ],
    [ "_upper", "classspatial_1_1closed__bounds.html#ac8c6f852403059da1010ee6331acdc38", null ]
];