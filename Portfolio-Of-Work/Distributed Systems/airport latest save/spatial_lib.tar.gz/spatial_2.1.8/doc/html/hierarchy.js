var hierarchy =
[
    [ "Accessor", null, [
      [ "spatial::accessor_less< Accessor, Tp >", "structspatial_1_1accessor__less.html", null ],
      [ "spatial::accessor_minus< Accessor, Tp, Unit >", "structspatial_1_1accessor__minus.html", null ]
    ] ],
    [ "Balancing", null, [
      [ "spatial::details::Compress< Balancing, key_compare >", "structspatial_1_1details_1_1_compress.html", null ]
    ] ],
    [ "Bidirectional_iterator            ", null, [
      [ "spatial::equal_iterator< Container >", "classspatial_1_1equal__iterator.html", null ],
      [ "spatial::region_iterator< Ct, Predicate >", "classspatial_1_1region__iterator.html", null ]
    ] ],
    [ "spatial::bracket_less< Tp >", "structspatial_1_1bracket__less.html", null ],
    [ "spatial::bracket_minus< Tp, Unit >", "structspatial_1_1bracket__minus.html", null ],
    [ "spatial::details::builtin_difference< typename >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_59099a0fc4a5615ef2ea9da95a88b852", null ],
    [ "spatial::details::builtin_difference< accessor_less< Accessor, Key > >", "structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_76096a2bd6208a794402c727abca26bd.html", null ],
    [ "spatial::details::builtin_difference< bracket_less< Key > >", "structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_d647d8777aaf298cb0a69d8fbe8b4887.html", null ],
    [ "spatial::details::builtin_difference< iterator_less< Key > >", "structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_7c5453d0cde1f2758fa33ccb275cf051.html", null ],
    [ "spatial::details::builtin_difference< paren_less< Key > >", "structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_b406b3a7892ffc242bcc4ddfe186df02.html", null ],
    [ "Compare", null, [
      [ "spatial::bounds< Key, Compare >", "classspatial_1_1bounds.html", null ],
      [ "spatial::closed_bounds< Key, Compare >", "classspatial_1_1closed__bounds.html", null ],
      [ "spatial::enclosed_bounds< Key, Compare, Layout >", "classspatial_1_1enclosed__bounds.html", null ],
      [ "spatial::open_bounds< Key, Compare >", "classspatial_1_1open__bounds.html", null ],
      [ "spatial::overlap_bounds< Key, Compare, Layout >", "classspatial_1_1overlap__bounds.html", null ]
    ] ],
    [ "spatial::details::condition< bool, Tp1, Tp2 >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1condition", null ],
    [ "spatial::details::condition< false, Tp1, Tp2 >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1condition_3_01false_00_01_tp1_00_01_tp2_01_4", null ],
    [ "Const_bidirectional_iterator            ", null, [
      [ "spatial::equal_iterator< const Container >", "classspatial_1_1equal__iterator_3_01const_01_container_01_4.html", null ],
      [ "spatial::neighbor_iterator< const Ct, Metric >", "classspatial_1_1neighbor__iterator_3_01const_01_ct_00_01_metric_01_4.html", null ],
      [ "spatial::region_iterator< const Ct, Predicate >", "classspatial_1_1region__iterator_3_01const_01_ct_00_01_predicate_01_4.html", null ]
    ] ],
    [ "spatial::details::Const_node_iterator< Link >", "classspatial_1_1details_1_1_const__node__iterator.html", null ],
    [ "spatial::container_traits< Tp >", "namespacespatial.html#structspatial_1_1container__traits", null ],
    [ "spatial::container_traits< const Ct >", "namespacespatial.html#namespacespatial", null ],
    [ "spatial::container_traits< Ct >", "namespacespatial.html#namespacespatial", null ],
    [ "Diff", null, [
      [ "spatial::euclidian< Ct, DistanceType, Diff >", "classspatial_1_1euclidian.html", [
        [ "spatial::details::Compress< euclidian< Ct, DistanceType, Diff >, typename spatial::container_traits< const Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ],
        [ "spatial::details::Compress< euclidian< Ct, DistanceType, Diff >, typename spatial::container_traits< Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ]
      ] ],
      [ "spatial::manhattan< Ct, DistanceType, Diff >", "classspatial_1_1manhattan.html", [
        [ "spatial::details::Compress< manhattan< Ct, DistanceType, Diff >, typename spatial::container_traits< const Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ],
        [ "spatial::details::Compress< manhattan< Ct, DistanceType, Diff >, typename spatial::container_traits< Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ]
      ] ],
      [ "spatial::quadrance< Ct, DistanceType, Diff >", "classspatial_1_1quadrance.html", [
        [ "spatial::details::Compress< quadrance< Ct, DistanceType, Diff >, typename spatial::container_traits< const Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ],
        [ "spatial::details::Compress< quadrance< Ct, DistanceType, Diff >, typename spatial::container_traits< Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ]
      ] ]
    ] ],
    [ "spatial::details::Dynamic_rank", "structspatial_1_1details_1_1_dynamic__rank.html", null ],
    [ "spatial::enable_if_c< B, Tp >", "namespacespatial.html#structspatial_1_1enable__if__c", null ],
    [ "spatial::enable_if_c< Cond::value, Tp >", "namespacespatial.html", [
      [ "spatial::enable_if< Cond, Tp >", "structspatial_1_1enable__if.html", null ]
    ] ],
    [ "spatial::enable_if_c< true, Tp >", "namespacespatial.html#structspatial_1_1enable__if__c_3_01true_00_01_tp_01_4", null ],
    [ "std::exception", null, [
      [ "std::logic_error", null, [
        [ "spatial::arithmetic_error", "structspatial_1_1arithmetic__error.html", null ],
        [ "spatial::invalid_bounds", "structspatial_1_1invalid__bounds.html", null ],
        [ "spatial::invalid_box", "structspatial_1_1invalid__box.html", null ],
        [ "spatial::invalid_dimension", "structspatial_1_1invalid__dimension.html", null ],
        [ "spatial::invalid_distance", "structspatial_1_1invalid__distance.html", null ],
        [ "spatial::invalid_empty_container", "structspatial_1_1invalid__empty__container.html", null ],
        [ "spatial::invalid_iterator", "structspatial_1_1invalid__iterator.html", null ],
        [ "spatial::invalid_node", "structspatial_1_1invalid__node.html", null ],
        [ "spatial::invalid_odd_rank", "structspatial_1_1invalid__odd__rank.html", null ],
        [ "spatial::invalid_rank", "structspatial_1_1invalid__rank.html", null ]
      ] ]
    ] ],
    [ "spatial::hhll_layout_tag", "namespacespatial.html#structspatial_1_1hhll__layout__tag", null ],
    [ "spatial::hlhl_layout_tag", "namespacespatial.html#structspatial_1_1hlhl__layout__tag", null ],
    [ "spatial::iterator_less< Tp >", "structspatial_1_1iterator__less.html", null ],
    [ "spatial::iterator_minus< Tp, Unit >", "structspatial_1_1iterator__minus.html", null ],
    [ "spatial::details::Kdtree< Rank, Key, Value, Compare, Alloc >", "classspatial_1_1details_1_1_kdtree.html", null ],
    [ "spatial::details::Kdtree< details::Dynamic_rank, const Key, const Key, Compare, Alloc >", "classspatial_1_1details_1_1_kdtree.html", [
      [ "spatial::idle_box_multiset< 0, Key, Compare, Alloc >", "classspatial_1_1idle__box__multiset_3_010_00_01_key_00_01_compare_00_01_alloc_01_4.html", null ],
      [ "spatial::idle_point_multiset< 0, Key, Compare, Alloc >", "structspatial_1_1idle__point__multiset_3_010_00_01_key_00_01_compare_00_01_alloc_01_4.html", null ]
    ] ],
    [ "spatial::details::Kdtree< details::Dynamic_rank, const Key, std::pair< const Key, Mapped >, Compare, Alloc >", "classspatial_1_1details_1_1_kdtree.html", [
      [ "spatial::idle_box_multimap< 0, Key, Mapped, Compare, Alloc >", "classspatial_1_1idle__box__multimap_3_010_00_01_key_00_01_mapped_00_01_compare_00_01_alloc_01_4.html", null ],
      [ "spatial::idle_point_multimap< 0, Key, Mapped, Compare, Alloc >", "structspatial_1_1idle__point__multimap_3_010_00_01_key_00_01_mapped_00_01_compare_00_01_alloc_01_4.html", null ]
    ] ],
    [ "spatial::details::Kdtree< details::Static_rank< Rank >, const Key, const Key, Compare, Alloc >", "classspatial_1_1details_1_1_kdtree.html", [
      [ "spatial::idle_box_multiset< Rank, Key, Compare, Alloc >", "classspatial_1_1idle__box__multiset.html", null ],
      [ "spatial::idle_point_multiset< Rank, Key, Compare, Alloc >", "structspatial_1_1idle__point__multiset.html", null ]
    ] ],
    [ "spatial::details::Kdtree< details::Static_rank< Rank >, const Key, std::pair< const Key, Mapped >, Compare, Alloc >", "classspatial_1_1details_1_1_kdtree.html", [
      [ "spatial::idle_box_multimap< Rank, Key, Mapped, Compare, Alloc >", "classspatial_1_1idle__box__multimap.html", null ],
      [ "spatial::idle_point_multimap< Rank, Key, Mapped, Compare, Alloc >", "structspatial_1_1idle__point__multimap.html", null ]
    ] ],
    [ "key_compare", null, [
      [ "spatial::details::Compress< key_compare, size_type >", "structspatial_1_1details_1_1_compress.html", null ],
      [ "spatial::details::Kdtree< Rank, Key, Value, Compare, Alloc >::Maximum", "structspatial_1_1details_1_1_kdtree_1_1_maximum.html", null ]
    ] ],
    [ "key_compare", null, [
      [ "spatial::details::Equal< Container >", "structspatial_1_1details_1_1_equal.html", null ],
      [ "spatial::details::Mapping< Container >", "structspatial_1_1details_1_1_mapping.html", null ]
    ] ],
    [ "key_compare", null, [
      [ "spatial::details::Mapping< Ct >", "structspatial_1_1details_1_1_mapping.html", null ]
    ] ],
    [ "key_compare", null, [
      [ "spatial::details::Neighbor_data< const Ct, euclidian< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< const Ct, manhattan< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< const Ct, quadrance< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< Ct, euclidian< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< Ct, manhattan< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< Ct, quadrance< Ct, DistanceType, Diff > >", "structspatial_1_1details_1_1_neighbor__data.html", null ],
      [ "spatial::details::Neighbor_data< Ct, Metric >", "structspatial_1_1details_1_1_neighbor__data.html", null ]
    ] ],
    [ "KeyCompare", null, [
      [ "spatial::details::ValueCompare< Value, KeyCompare >", "structspatial_1_1details_1_1_value_compare.html", null ]
    ] ],
    [ "spatial::lhlh_layout_tag", "namespacespatial.html#structspatial_1_1lhlh__layout__tag", null ],
    [ "Link_allocator", null, [
      [ "spatial::details::Compress< Link_allocator, spatial::details::Node< spatial::details::Kdtree_link > >", "structspatial_1_1details_1_1_compress.html", null ],
      [ "spatial::details::Compress< Link_allocator, spatial::details::Node< spatial::details::Relaxed_kdtree_link > >", "structspatial_1_1details_1_1_compress.html", null ]
    ] ],
    [ "spatial::llhh_layout_tag", "namespacespatial.html#structspatial_1_1llhh__layout__tag", null ],
    [ "spatial::loose_balancing", "structspatial_1_1loose__balancing.html", null ],
    [ "spatial::details::mapping_compare< Compare, Node_ptr >", "structspatial_1_1details_1_1mapping__compare.html", null ],
    [ "spatial::metric_traits< Tp >", "namespacespatial.html#structspatial_1_1metric__traits", null ],
    [ "spatial::mode_traits< Mode >", "namespacespatial.html#structspatial_1_1mode__traits", null ],
    [ "spatial::details::mutate< Tp >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1mutate", null ],
    [ "spatial::details::mutate< const Tp >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1mutate_3_01const_01_tp_01_4", null ],
    [ "spatial::details::Node< Link >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1_node", null ],
    [ "spatial::details::Node< Kdtree_link< Key, Value > >", "namespacespatial_1_1details.html", [
      [ "spatial::details::Kdtree_link< Key, Value >", "structspatial_1_1details_1_1_kdtree__link.html", null ]
    ] ],
    [ "spatial::details::Node< Relaxed_kdtree_link< Key, Value > >", "namespacespatial_1_1details.html", [
      [ "spatial::details::Relaxed_kdtree_link< Key, Value >", "structspatial_1_1details_1_1_relaxed__kdtree__link.html", null ]
    ] ],
    [ "spatial::details::Node< spatial::details::Kdtree_link >", "namespacespatial_1_1details.html#namespacespatial_1_1details", null ],
    [ "spatial::details::Node< spatial::details::Relaxed_kdtree_link >", "namespacespatial_1_1details.html#namespacespatial_1_1details", null ],
    [ "spatial::details::Node_iterator< Link >", "classspatial_1_1details_1_1_node__iterator.html", null ],
    [ "pair", null, [
      [ "spatial::neighbor_iterator_pair< const Ct, euclidian< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::euclidian_neighbor_iterator_pair< const Ct, DistanceType, Diff >", "classspatial_1_1euclidian__neighbor__iterator__pair_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
      ] ],
      [ "spatial::neighbor_iterator_pair< const Ct, manhattan< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::manhattan_neighbor_iterator_pair< const Ct, DistanceType, Diff >", "classspatial_1_1manhattan__neighbor__iterator__pair_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
      ] ],
      [ "spatial::neighbor_iterator_pair< const Ct, quadrance< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::quadrance_neighbor_iterator_pair< const Ct, DistanceType, Diff >", "classspatial_1_1quadrance__neighbor__iterator__pair_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
      ] ],
      [ "spatial::neighbor_iterator_pair< Ct, euclidian< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::euclidian_neighbor_iterator_pair< Ct, DistanceType, Diff >", "classspatial_1_1euclidian__neighbor__iterator__pair.html", null ]
      ] ],
      [ "spatial::neighbor_iterator_pair< Ct, manhattan< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::manhattan_neighbor_iterator_pair< Ct, DistanceType, Diff >", "classspatial_1_1manhattan__neighbor__iterator__pair.html", null ]
      ] ],
      [ "spatial::neighbor_iterator_pair< Ct, quadrance< Ct, DistanceType, Diff > >", "structspatial_1_1neighbor__iterator__pair.html", [
        [ "spatial::quadrance_neighbor_iterator_pair< Ct, DistanceType, Diff >", "classspatial_1_1quadrance__neighbor__iterator__pair.html", null ]
      ] ],
      [ "spatial::region_iterator_pair< Ct, closed_bounds< container_traits< Ct >::key_type, container_traits< Ct >::key_compare > >", "structspatial_1_1region__iterator__pair.html", [
        [ "spatial::closed_region_iterator_pair< Ct >", "structspatial_1_1closed__region__iterator__pair.html", null ]
      ] ],
      [ "spatial::equal_iterator_pair< Container >", "structspatial_1_1equal__iterator__pair.html", null ],
      [ "spatial::equal_iterator_pair< const Container >", "structspatial_1_1equal__iterator__pair_3_01const_01_container_01_4.html", null ],
      [ "spatial::mapping_iterator_pair< Ct >", "structspatial_1_1mapping__iterator__pair.html", null ],
      [ "spatial::mapping_iterator_pair< const Ct >", "structspatial_1_1mapping__iterator__pair_3_01const_01_ct_01_4.html", null ],
      [ "spatial::neighbor_iterator_pair< Ct, Metric >", "structspatial_1_1neighbor__iterator__pair.html", null ],
      [ "spatial::neighbor_iterator_pair< const Ct, Metric >", "structspatial_1_1neighbor__iterator__pair_3_01const_01_ct_00_01_metric_01_4.html", null ],
      [ "spatial::ordered_iterator_pair< Ct >", "structspatial_1_1ordered__iterator__pair.html", null ],
      [ "spatial::ordered_iterator_pair< const Ct >", "structspatial_1_1ordered__iterator__pair_3_01const_01_ct_01_4.html", null ],
      [ "spatial::region_iterator_pair< Ct, Predicate >", "structspatial_1_1region__iterator__pair.html", null ],
      [ "spatial::region_iterator_pair< const Ct, Predicate >", "structspatial_1_1region__iterator__pair_3_01const_01_ct_00_01_predicate_01_4.html", null ]
    ] ],
    [ "spatial::paren_less< Tp >", "structspatial_1_1paren__less.html", null ],
    [ "spatial::paren_minus< Tp, Unit >", "structspatial_1_1paren__minus.html", null ],
    [ "spatial::perfect_balancing", "structspatial_1_1perfect__balancing.html", null ],
    [ "spatial::details::Preorder_node_iterator< Link >", "structspatial_1_1details_1_1_preorder__node__iterator.html", null ],
    [ "rank_type", null, [
      [ "spatial::details::Relaxed_kdtree< Rank, Key, Value, Compare, Balancing, Alloc >::Implementation", "structspatial_1_1details_1_1_relaxed__kdtree_1_1_implementation.html", null ]
    ] ],
    [ "rank_type", null, [
      [ "spatial::details::Bidirectional_iterator< container_traits< const Ct >::mode_type, container_traits< const Ct >::rank_type >", "classspatial_1_1details_1_1_bidirectional__iterator.html", [
        [ "spatial::neighbor_iterator< const Ct, euclidian< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::euclidian_neighbor_iterator< const Ct, DistanceType, Diff >", "classspatial_1_1euclidian__neighbor__iterator_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
        ] ],
        [ "spatial::neighbor_iterator< const Ct, manhattan< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::manhattan_neighbor_iterator< const Ct, DistanceType, Diff >", "classspatial_1_1manhattan__neighbor__iterator_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
        ] ],
        [ "spatial::neighbor_iterator< const Ct, quadrance< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::quadrance_neighbor_iterator< const Ct, DistanceType, Diff >", "classspatial_1_1quadrance__neighbor__iterator_3_01const_01_ct_00_01_distance_type_00_01_diff_01_4.html", null ]
        ] ]
      ] ],
      [ "spatial::details::Bidirectional_iterator< container_traits< Ct >::mode_type, container_traits< Ct >::rank_type >", "classspatial_1_1details_1_1_bidirectional__iterator.html", [
        [ "spatial::neighbor_iterator< Ct, euclidian< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::euclidian_neighbor_iterator< Ct, DistanceType, Diff >", "classspatial_1_1euclidian__neighbor__iterator.html", null ]
        ] ],
        [ "spatial::neighbor_iterator< Ct, manhattan< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::manhattan_neighbor_iterator< Ct, DistanceType, Diff >", "classspatial_1_1manhattan__neighbor__iterator.html", null ]
        ] ],
        [ "spatial::neighbor_iterator< Ct, quadrance< Ct, DistanceType, Diff > >", "classspatial_1_1neighbor__iterator.html", [
          [ "spatial::quadrance_neighbor_iterator< Ct, DistanceType, Diff >", "classspatial_1_1quadrance__neighbor__iterator.html", null ]
        ] ],
        [ "spatial::mapping_iterator< Ct >", "classspatial_1_1mapping__iterator.html", null ],
        [ "spatial::neighbor_iterator< Ct, Metric >", "classspatial_1_1neighbor__iterator.html", null ],
        [ "spatial::ordered_iterator< Ct >", "classspatial_1_1ordered__iterator.html", null ]
      ] ],
      [ "spatial::details::Const_bidirectional_iterator< container_traits< Ct >::mode_type, container_traits< Ct >::rank_type >", "classspatial_1_1details_1_1_const__bidirectional__iterator.html", [
        [ "spatial::mapping_iterator< const Ct >", "classspatial_1_1mapping__iterator_3_01const_01_ct_01_4.html", null ],
        [ "spatial::ordered_iterator< const Ct >", "classspatial_1_1ordered__iterator_3_01const_01_ct_01_4.html", null ]
      ] ]
    ] ],
    [ "spatial::details::rebind_builtin_difference< Diff, DistanceType >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1rebind__builtin__difference", null ],
    [ "spatial::details::rebind_builtin_difference< accessor_minus< Accessor, Tp, Unit >,                                                                                                                                                                                                                                                                                   DistanceType >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1rebind__builtin__difference_3_01accessor__minus_3_01_accessor_00_01_393254571a4d811df9d06aa5d699801c", null ],
    [ "spatial::details::rebind_builtin_difference< bracket_minus< Tp, Unit >, DistanceType >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1rebind__builtin__difference_3_01bracket__minus_3_01_tp_00_01_unit_01_4_00_01_distance_type_01_4", null ],
    [ "spatial::details::rebind_builtin_difference< iterator_minus< Tp, Unit >, DistanceType >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1rebind__builtin__difference_3_01iterator__minus_3_01_tp_00_01_unit_01_4_00_01_distance_type_01_4", null ],
    [ "spatial::details::rebind_builtin_difference< paren_minus< Tp, Unit >, DistanceType >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1rebind__builtin__difference_3_01paren__minus_3_01_tp_00_01_unit_01_4_00_01_distance_type_01_4", null ],
    [ "region_iterator            ", null, [
      [ "spatial::closed_region_iterator< Ct >", "structspatial_1_1closed__region__iterator.html", null ],
      [ "spatial::closed_region_iterator< const Ct >", "structspatial_1_1closed__region__iterator_3_01const_01_ct_01_4.html", null ],
      [ "spatial::enclosed_region_iterator< Ct, Layout >", "structspatial_1_1enclosed__region__iterator.html", null ],
      [ "spatial::enclosed_region_iterator< const Ct, Layout >", "structspatial_1_1enclosed__region__iterator_3_01const_01_ct_00_01_layout_01_4.html", null ],
      [ "spatial::open_region_iterator< Ct >", "structspatial_1_1open__region__iterator.html", null ],
      [ "spatial::open_region_iterator< const Ct >", "structspatial_1_1open__region__iterator_3_01const_01_ct_01_4.html", null ],
      [ "spatial::overlap_region_iterator< Ct, Layout >", "structspatial_1_1overlap__region__iterator.html", null ],
      [ "spatial::overlap_region_iterator< const Ct, Layout >", "structspatial_1_1overlap__region__iterator_3_01const_01_ct_00_01_layout_01_4.html", null ]
    ] ],
    [ "region_iterator_pair            ", null, [
      [ "spatial::closed_region_iterator_pair< const Ct >", "structspatial_1_1closed__region__iterator__pair_3_01const_01_ct_01_4.html", null ],
      [ "spatial::enclosed_region_iterator_pair< Ct, Layout >", "structspatial_1_1enclosed__region__iterator__pair.html", null ],
      [ "spatial::enclosed_region_iterator_pair< const Ct, Layout >", "structspatial_1_1enclosed__region__iterator__pair_3_01const_01_ct_00_01_layout_01_4.html", null ],
      [ "spatial::open_region_iterator_pair< Ct >", "structspatial_1_1open__region__iterator__pair.html", null ],
      [ "spatial::open_region_iterator_pair< const Ct >", "structspatial_1_1open__region__iterator__pair_3_01const_01_ct_01_4.html", null ],
      [ "spatial::overlap_region_iterator_pair< Ct, Layout >", "structspatial_1_1overlap__region__iterator__pair.html", null ],
      [ "spatial::overlap_region_iterator_pair< const Ct, Layout >", "structspatial_1_1overlap__region__iterator__pair_3_01const_01_ct_00_01_layout_01_4.html", null ]
    ] ],
    [ "spatial::details::relaxed_invariant_tag", "namespacespatial_1_1details.html#structspatial_1_1details_1_1relaxed__invariant__tag", null ],
    [ "spatial::details::Relaxed_kdtree< Rank, Key, Value, Compare, Balancing, Alloc >", "classspatial_1_1details_1_1_relaxed__kdtree.html", null ],
    [ "spatial::details::Relaxed_kdtree< details::Dynamic_rank, const Key, const Key, Compare, BalancingPolicy, Alloc >", "classspatial_1_1details_1_1_relaxed__kdtree.html", [
      [ "spatial::box_multiset< 0, Key, Compare, BalancingPolicy, Alloc >", "classspatial_1_1box__multiset_3_010_00_01_key_00_01_compare_00_01_balancing_policy_00_01_alloc_01_4.html", null ],
      [ "spatial::point_multiset< 0, Key, Compare, BalancingPolicy, Alloc >", "structspatial_1_1point__multiset_3_010_00_01_key_00_01_compare_00_01_balancing_policy_00_01_alloc_01_4.html", null ]
    ] ],
    [ "spatial::details::Relaxed_kdtree< details::Dynamic_rank, const Key, std::pair< const Key, Mapped >, Compare, BalancingPolicy, Alloc >", "classspatial_1_1details_1_1_relaxed__kdtree.html", [
      [ "spatial::box_multimap< 0, Key, Mapped, Compare, BalancingPolicy, Alloc >", "structspatial_1_1box__multimap_3_010_00_01_key_00_01_mapped_00_01_compare_00_01_balancing_policy_00_01_alloc_01_4.html", null ],
      [ "spatial::point_multimap< 0, Key, Mapped, Compare, BalancingPolicy, Alloc >", "structspatial_1_1point__multimap_3_010_00_01_key_00_01_mapped_00_01_compare_00_01_balancing_policy_00_01_alloc_01_4.html", null ]
    ] ],
    [ "spatial::details::Relaxed_kdtree< details::Static_rank< Rank >, const Key, const Key, Compare, BalancingPolicy, Alloc >", "classspatial_1_1details_1_1_relaxed__kdtree.html", [
      [ "spatial::box_multiset< Rank, Key, Compare, BalancingPolicy, Alloc >", "classspatial_1_1box__multiset.html", null ],
      [ "spatial::point_multiset< Rank, Key, Compare, BalancingPolicy, Alloc >", "structspatial_1_1point__multiset.html", null ]
    ] ],
    [ "spatial::details::Relaxed_kdtree< details::Static_rank< Rank >, const Key, std::pair< const Key, Mapped >, Compare, BalancingPolicy, Alloc >", "classspatial_1_1details_1_1_relaxed__kdtree.html", [
      [ "spatial::box_multimap< Rank, Key, Mapped, Compare, BalancingPolicy, Alloc >", "classspatial_1_1box__multimap.html", null ],
      [ "spatial::point_multimap< Rank, Key, Mapped, Compare, BalancingPolicy, Alloc >", "structspatial_1_1point__multimap.html", null ]
    ] ],
    [ "spatial::details::Relaxed_kdtree< Rank, Key, Value, Compare, Balancing, Alloc >::safe_allocator", "structspatial_1_1details_1_1_relaxed__kdtree_1_1safe__allocator.html", null ],
    [ "spatial::details::Kdtree< Rank, Key, Value, Compare, Alloc >::safe_allocator", "structspatial_1_1details_1_1_kdtree_1_1safe__allocator.html", null ],
    [ "spatial::details::Static_rank< Value >", "structspatial_1_1details_1_1_static__rank.html", null ],
    [ "spatial::details::strict_invariant_tag", "namespacespatial_1_1details.html#structspatial_1_1details_1_1strict__invariant__tag", null ],
    [ "spatial::details::template_member_assign_provider< bool, Tp >", "structspatial_1_1details_1_1template__member__assign__provider.html", null ],
    [ "spatial::details::template_member_assign_provider< import::is_empty< Tp >::value, Tp >", "structspatial_1_1details_1_1template__member__assign__provider.html", [
      [ "spatial::details::template_member_assign< Tp >", "structspatial_1_1details_1_1template__member__assign.html", null ]
    ] ],
    [ "spatial::details::template_member_assign_provider< true, Tp >", "structspatial_1_1details_1_1template__member__assign__provider_3_01true_00_01_tp_01_4.html", null ],
    [ "spatial::details::template_member_swap_provider< bool, Tp >", "structspatial_1_1details_1_1template__member__swap__provider.html", null ],
    [ "spatial::details::template_member_swap_provider< import::is_empty< Tp >::value, Tp >", "structspatial_1_1details_1_1template__member__swap__provider.html", [
      [ "spatial::details::template_member_swap< Tp >", "structspatial_1_1details_1_1template__member__swap.html", null ]
    ] ],
    [ "spatial::details::template_member_swap_provider< true, Tp >", "structspatial_1_1details_1_1template__member__swap__provider_3_01true_00_01_tp_01_4.html", null ],
    [ "spatial::tight_balancing", "structspatial_1_1tight__balancing.html", null ],
    [ "spatial::details::with_builtin_difference< Container, Enable >", "namespacespatial_1_1details.html#structspatial_1_1details_1_1with__builtin__difference", null ],
    [ "spatial::details::with_builtin_difference    < Container,                   typename enable_if< is_compare_builtin< Container > >::type >", "structspatial_1_1details_1_1with__builtin__difference_01_01_01_01_3_01_container_00_01_01_01_01_7c2be3f9bbac6e8e581451acc869e652.html", null ],
    [ "Base", null, [
      [ "spatial::details::Compress< Base, Member >", "structspatial_1_1details_1_1_compress.html", null ]
    ] ],
    [ "false_type", null, [
      [ "spatial::details::is_compare_builtin_helper< container_traits< Ct >::key_compare >", "structspatial_1_1details_1_1is__compare__builtin__helper.html", [
        [ "spatial::details::is_compare_builtin< Ct >", "structspatial_1_1details_1_1is__compare__builtin.html", null ]
      ] ],
      [ "spatial::details::is_compare_builtin_helper< typename >", "structspatial_1_1details_1_1is__compare__builtin__helper.html", null ],
      [ "spatial::details::is_difference_builtin< typename >", "structspatial_1_1details_1_1is__difference__builtin.html", null ]
    ] ],
    [ "Metric", null, [
      [ "spatial::details::Compress< Metric, typename spatial::container_traits< Ct >::key_type >", "structspatial_1_1details_1_1_compress.html", null ]
    ] ],
    [ "Rank", null, [
      [ "spatial::details::Bidirectional_iterator< Link, Rank >", "classspatial_1_1details_1_1_bidirectional__iterator.html", null ],
      [ "spatial::details::Const_bidirectional_iterator< Link, Rank >", "classspatial_1_1details_1_1_const__bidirectional__iterator.html", null ],
      [ "spatial::details::Kdtree< Rank, Key, Value, Compare, Alloc >::Implementation", "structspatial_1_1details_1_1_kdtree_1_1_implementation.html", null ]
    ] ],
    [ "true_type", null, [
      [ "spatial::details::is_compare_builtin_helper< accessor_less< Accessor, Tp > >", "structspatial_1_1details_1_1is__compare__builtin__helper_3_01accessor__less_3_01_accessor_00_01_tp_01_4_01_4.html", null ],
      [ "spatial::details::is_compare_builtin_helper< bracket_less< Tp > >", "structspatial_1_1details_1_1is__compare__builtin__helper_3_01bracket__less_3_01_tp_01_4_01_4.html", null ],
      [ "spatial::details::is_compare_builtin_helper< iterator_less< Tp > >", "structspatial_1_1details_1_1is__compare__builtin__helper_3_01iterator__less_3_01_tp_01_4_01_4.html", null ],
      [ "spatial::details::is_compare_builtin_helper< paren_less< Tp > >", "structspatial_1_1details_1_1is__compare__builtin__helper_3_01paren__less_3_01_tp_01_4_01_4.html", null ],
      [ "spatial::details::is_difference_builtin< accessor_minus< Accessor, Tp, Unit > >", "structspatial_1_1details_1_1is__difference__builtin_3_01accessor__minus_3_01_accessor_00_01_tp_00_01_unit_01_4_01_4.html", null ],
      [ "spatial::details::is_difference_builtin< bracket_minus< Tp, Unit > >", "structspatial_1_1details_1_1is__difference__builtin_3_01bracket__minus_3_01_tp_00_01_unit_01_4_01_4.html", null ],
      [ "spatial::details::is_difference_builtin< iterator_minus< Tp, Unit > >", "structspatial_1_1details_1_1is__difference__builtin_3_01iterator__minus_3_01_tp_00_01_unit_01_4_01_4.html", null ],
      [ "spatial::details::is_difference_builtin< paren_minus< Tp, Unit > >", "structspatial_1_1details_1_1is__difference__builtin_3_01paren__minus_3_01_tp_00_01_unit_01_4_01_4.html", null ]
    ] ]
];